# Distributed under the OSI-approved BSD 3-Clause License.  See accompanying
# file Copyright.txt or https://cmake.org/licensing for details.

cmake_minimum_required(VERSION ${CMAKE_VERSION}) # this file comes with cmake

# If CMAKE_DISABLE_SOURCE_CHANGES is set to true and the source directory is an
# existing directory in our source tree, calling file(MAKE_DIRECTORY) on it
# would cause a fatal error, even though it would be a no-op.
if(NOT EXISTS "/home/erashov/Documents/u3media/u3builds-extlibs-OrangePi-Clang-22-Clang-22--aarch64-Release-ub/dlib-util/src/dlib-util")
  file(MAKE_DIRECTORY "/home/erashov/Documents/u3media/u3builds-extlibs-OrangePi-Clang-22-Clang-22--aarch64-Release-ub/dlib-util/src/dlib-util")
endif()
file(MAKE_DIRECTORY
  "/home/erashov/Documents/u3media/u3builds-extlibs-OrangePi-Clang-22-Clang-22--aarch64-Release-ub/dlib-util/src/dlib-util-build"
  "/home/erashov/Documents/u3media/u3builds-extlibs-OrangePi-Clang-22-Clang-22--aarch64-Release-ub/dlib-util"
  "/home/erashov/Documents/u3media/u3builds-extlibs-OrangePi-Clang-22-Clang-22--aarch64-Release-ub/dlib-util/tmp"
  "/home/erashov/Documents/u3media/u3builds-extlibs-OrangePi-Clang-22-Clang-22--aarch64-Release-ub/dlib-util/src/dlib-util-stamp"
  "/home/erashov/Documents/u3media/u3builds-extlibs-OrangePi-Clang-22-Clang-22--aarch64-Release-ub/dlib-util/src"
  "/home/erashov/Documents/u3media/u3builds-extlibs-OrangePi-Clang-22-Clang-22--aarch64-Release-ub/dlib-util/src/dlib-util-stamp"
)

set(configSubDirs )
foreach(subDir IN LISTS configSubDirs)
    file(MAKE_DIRECTORY "/home/erashov/Documents/u3media/u3builds-extlibs-OrangePi-Clang-22-Clang-22--aarch64-Release-ub/dlib-util/src/dlib-util-stamp/${subDir}")
endforeach()
if(cfgdir)
  file(MAKE_DIRECTORY "/home/erashov/Documents/u3media/u3builds-extlibs-OrangePi-Clang-22-Clang-22--aarch64-Release-ub/dlib-util/src/dlib-util-stamp${cfgdir}") # cfgdir has leading slash
endif()
