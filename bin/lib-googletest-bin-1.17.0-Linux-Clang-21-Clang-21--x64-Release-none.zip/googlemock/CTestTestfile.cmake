# CMake generated Testfile for 
# Source directory: /home/erashov/Documents/u3temp-Linux-Clang-_21_1_8-Clang-_21_1_8--x64-Release-none/googletest-util/src/googletest-util/googlemock
# Build directory: /home/erashov/Documents/u3temp-Linux-Clang-_21_1_8-Clang-_21_1_8--x64-Release-none/googletest-util/src/googletest-util-build/googlemock
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
subdirs("../googletest")
