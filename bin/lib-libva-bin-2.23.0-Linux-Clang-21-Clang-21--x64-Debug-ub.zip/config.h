/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* Define if SSP C support is enabled. */
/* #undef ENABLE_SSP_CC */

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* Defined to 1 if EMGD is built */
/* #undef HAVE_EMGD */

/* Defined to 1 if FGLRX is built */
/* #undef HAVE_FGLRX */

/* Define to 1 if you have the <GL/glx.h> header file. */
/* #undef HAVE_GL_GLX_H */

/* Define to 1 if you have the <GL/gl.h> header file. */
/* #undef HAVE_GL_GL_H */

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Defined to 1 if NVCTRL is built */
/* #undef HAVE_NVCTRL */

/* Define to 1 if you have the 'secure_getenv' function. */
#define HAVE_SECURE_GETENV 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdio.h> header file. */
#define HAVE_STDIO_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Defined to 1 if VA/DRM API is built */
#define HAVE_VA_DRM 1

/* Defined to 1 if VA/GLX API is built */
/* #undef HAVE_VA_GLX */

/* Defined to 1 if VA/Wayland API is built */
/* #undef HAVE_VA_WAYLAND */

/* Defined to 1 if VA/X11 API is built */
/* #undef HAVE_VA_X11 */

/* Define to the sub-directory where libtool stores uninstalled libraries. */
#define LT_OBJDIR ".libs/"

/* Name of package */
#define PACKAGE "libva"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "https://github.com/intel/libva/issues/new"

/* Define to the full name of this package. */
#define PACKAGE_NAME "libva"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "libva 2.24.0.pre1"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "libva"

/* Define to the home page for this package. */
#define PACKAGE_URL "https://github.com/intel/libva"

/* Define to the version of this package. */
#define PACKAGE_VERSION "2.24.0.pre1"

/* Define to 1 if all of the C89 standard headers exist (not just the ones
   required in a freestanding environment). This macro is provided for
   backward compatibility; new code need not use it. */
#define STDC_HEADERS 1

/* Version number of package */
#define VERSION "2.24.0.pre1"

/* Number of bits in a file offset, on hosts where this is settable. */
/* #undef _FILE_OFFSET_BITS */

/* Define to 1 on platforms where this makes off_t a 64-bit type. */
/* #undef _LARGE_FILES */

/* Number of bits in time_t, on hosts where this is settable. */
/* #undef _TIME_BITS */

/* Define to 1 on platforms where this makes time_t a 64-bit type. */
/* #undef __MINGW_USE_VC2005_COMPAT */
