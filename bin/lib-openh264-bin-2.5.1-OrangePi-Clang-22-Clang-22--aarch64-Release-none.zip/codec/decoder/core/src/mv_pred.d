codec/decoder/core/src/mv_pred.o: codec/decoder/core/src/mv_pred.cpp \
  codec/decoder/core/inc/mv_pred.h codec/decoder/core/inc/dec_frame.h \
  codec/common/inc/typedefs.h codec/decoder/core/inc/wels_const.h \
  codec/common/inc/wels_const_common.h \
  codec/decoder/core/inc/wels_common_basis.h codec/common/inc/macros.h \
  codec/common/inc/wels_common_defs.h codec/api/wels/codec_app_def.h \
  codec/api/wels/codec_def.h codec/decoder/core/inc/parameter_sets.h \
  codec/decoder/core/inc/nal_prefix.h codec/decoder/core/inc/slice.h \
  codec/decoder/core/inc/picture.h \
  codec/decoder/core/inc/wels_decoder_thread.h \
  codec/common/inc/WelsThreadLib.h codec/decoder/core/inc/bit_stream.h \
  codec/common/inc/golomb_common.h codec/decoder/core/inc/fmo.h \
  codec/common/inc/memory_align.h \
  codec/decoder/core/inc/decoder_context.h codec/common/inc/utils.h \
  codec/decoder/core/inc/nalu.h codec/decoder/core/inc/pic_queue.h \
  codec/decoder/core/inc/vlc_decoder.h \
  codec/decoder/core/inc/dec_golomb.h codec/common/inc/ls_defines.h \
  codec/decoder/core/inc/error_code.h codec/common/inc/crt_util_safe_x.h \
  codec/decoder/core/inc/mb_cache.h codec/common/inc/expand_pic.h \
  codec/common/inc/mc.h codec/decoder/core/inc/parse_mb_syn_cabac.h \
  codec/decoder/core/inc/cabac_decoder.h
codec/decoder/core/inc/mv_pred.h:
codec/decoder/core/inc/dec_frame.h:
codec/common/inc/typedefs.h:
codec/decoder/core/inc/wels_const.h:
codec/common/inc/wels_const_common.h:
codec/decoder/core/inc/wels_common_basis.h:
codec/common/inc/macros.h:
codec/common/inc/wels_common_defs.h:
codec/api/wels/codec_app_def.h:
codec/api/wels/codec_def.h:
codec/decoder/core/inc/parameter_sets.h:
codec/decoder/core/inc/nal_prefix.h:
codec/decoder/core/inc/slice.h:
codec/decoder/core/inc/picture.h:
codec/decoder/core/inc/wels_decoder_thread.h:
codec/common/inc/WelsThreadLib.h:
codec/decoder/core/inc/bit_stream.h:
codec/common/inc/golomb_common.h:
codec/decoder/core/inc/fmo.h:
codec/common/inc/memory_align.h:
codec/decoder/core/inc/decoder_context.h:
codec/common/inc/utils.h:
codec/decoder/core/inc/nalu.h:
codec/decoder/core/inc/pic_queue.h:
codec/decoder/core/inc/vlc_decoder.h:
codec/decoder/core/inc/dec_golomb.h:
codec/common/inc/ls_defines.h:
codec/decoder/core/inc/error_code.h:
codec/common/inc/crt_util_safe_x.h:
codec/decoder/core/inc/mb_cache.h:
codec/common/inc/expand_pic.h:
codec/common/inc/mc.h:
codec/decoder/core/inc/parse_mb_syn_cabac.h:
codec/decoder/core/inc/cabac_decoder.h:
