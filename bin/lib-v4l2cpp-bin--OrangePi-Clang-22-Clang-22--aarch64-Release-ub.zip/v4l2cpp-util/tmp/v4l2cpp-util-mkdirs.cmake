# Distributed under the OSI-approved BSD 3-Clause License.  See accompanying
# file Copyright.txt or https://cmake.org/licensing for details.

cmake_minimum_required(VERSION ${CMAKE_VERSION}) # this file comes with cmake

# If CMAKE_DISABLE_SOURCE_CHANGES is set to true and the source directory is an
# existing directory in our source tree, calling file(MAKE_DIRECTORY) on it
# would cause a fatal error, even though it would be a no-op.
if(NOT EXISTS "/home/erashov/Documents/u3media/u3builds-extlibs-OrangePi-Clang-22-Clang-22--aarch64-Release-ub/v4l2cpp-util/src/v4l2cpp-util")
  file(MAKE_DIRECTORY "/home/erashov/Documents/u3media/u3builds-extlibs-OrangePi-Clang-22-Clang-22--aarch64-Release-ub/v4l2cpp-util/src/v4l2cpp-util")
endif()
file(MAKE_DIRECTORY
  "/home/erashov/Documents/u3media/u3builds-extlibs-OrangePi-Clang-22-Clang-22--aarch64-Release-ub/v4l2cpp-util/src/v4l2cpp-util-build"
  "/home/erashov/Documents/u3media/u3builds-extlibs-OrangePi-Clang-22-Clang-22--aarch64-Release-ub/v4l2cpp-util"
  "/home/erashov/Documents/u3media/u3builds-extlibs-OrangePi-Clang-22-Clang-22--aarch64-Release-ub/v4l2cpp-util/tmp"
  "/home/erashov/Documents/u3media/u3builds-extlibs-OrangePi-Clang-22-Clang-22--aarch64-Release-ub/v4l2cpp-util/src/v4l2cpp-util-stamp"
  "/home/erashov/Documents/u3media/u3builds-extlibs-OrangePi-Clang-22-Clang-22--aarch64-Release-ub/v4l2cpp-util/src"
  "/home/erashov/Documents/u3media/u3builds-extlibs-OrangePi-Clang-22-Clang-22--aarch64-Release-ub/v4l2cpp-util/src/v4l2cpp-util-stamp"
)

set(configSubDirs )
foreach(subDir IN LISTS configSubDirs)
    file(MAKE_DIRECTORY "/home/erashov/Documents/u3media/u3builds-extlibs-OrangePi-Clang-22-Clang-22--aarch64-Release-ub/v4l2cpp-util/src/v4l2cpp-util-stamp/${subDir}")
endforeach()
if(cfgdir)
  file(MAKE_DIRECTORY "/home/erashov/Documents/u3media/u3builds-extlibs-OrangePi-Clang-22-Clang-22--aarch64-Release-ub/v4l2cpp-util/src/v4l2cpp-util-stamp${cfgdir}") # cfgdir has leading slash
endif()
